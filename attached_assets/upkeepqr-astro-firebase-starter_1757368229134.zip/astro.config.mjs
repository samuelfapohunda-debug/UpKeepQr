import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
export default defineConfig({
  site: 'https://www.upkeepqr.com',
  integrations: [tailwind({ config: { applyBaseStyles: false } })],
});
