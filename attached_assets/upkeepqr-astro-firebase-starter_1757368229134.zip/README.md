# UpkeepQR — Astro + Tailwind on Firebase (via Replit)

Includes:
- Astro + Tailwind marketing site
- Pages: Home, Order, Contact, Request a Pro, Fee Listing, FAQ, Privacy, Terms
- Header CTA to Stripe (1‑magnet Payment Link)
- Firebase Functions API for Postmark (contact/pro/listing)
- GA4 + SEO meta, social placeholders

## Local Dev on Replit
```bash
npm i
npm run dev
```
Create `.env`:
```
PUBLIC_GA_ID=G-XXXXXXXXXX
PUBLIC_STRIPE_LINK_1=https://buy.stripe.com/test_8x29AV0Q0cQB0KJbu5gIo00
PUBLIC_STRIPE_LINK_100=https://buy.stripe.com/test_eVq00l42c5o98db69LgIo01
PUBLIC_STRIPE_LINK_300=https://buy.stripe.com/test_9B6eVfaqA5o9fFDgOpgIo02
```

## Firebase deploy
```bash
npm i -g firebase-tools
firebase login
firebase use your-firebase-project-id
cd functions && npm i && cd ..
firebase functions:config:set postmark.token="POSTMARK_SERVER_TOKEN" support.email="support@upkeepqr.com"
npm run build
firebase deploy
```

## Notes
- `/api/*` routes are served by Firebase Function `api`.
- Forms POST to those endpoints and redirect with `?sent=1` / `?error=1`.
- Update Stripe links to your LIVE links before launch.
