/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: { navy: '#1E2A38', lime: '#B9E937', offwhite: '#F5F7FA' },
      fontFamily: {
        heading: ['Poppins', 'ui-sans-serif', 'system-ui'],
        body: ['Inter', 'ui-sans-serif', 'system-ui']
      },
      boxShadow: { soft: '0 8px 30px rgba(0,0,0,0.12)' }
    }
  },
  plugins: []
}
