import * as functions from 'firebase-functions';
import express from 'express';
import cors from 'cors';
import { ServerClient } from 'postmark';

const app = express();
app.use(cors({ origin: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

function getPostmark() {
  const token = (functions.config().postmark && functions.config().postmark.token) || process.env.POSTMARK_API_TOKEN;
  if (!token) throw new Error('POSTMARK token missing');
  return new ServerClient(token);
}
const SUPPORT = (functions.config().support && functions.config().support.email) || process.env.SUPPORT_EMAIL || 'support@upkeepqr.com';

app.post('/contact', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    const client = getPostmark();
    await client.sendEmail({ From: SUPPORT, To: SUPPORT, ReplyTo: email, Subject: 'UpkeepQR Contact', HtmlBody: `<strong>From:</strong> ${name} (${email})<br/><pre>${message}</pre>`, MessageStream: 'outbound' });
    await client.sendEmail({ From: SUPPORT, To: email, Subject: 'Thanks for contacting UpkeepQR', HtmlBody: `<p>Hi ${name},</p><p>Thanks for reaching out. We'll get back to you shortly.</p>`, MessageStream: 'outbound' });
    res.redirect('/contact?sent=1');
  } catch (e) { console.error(e); res.redirect('/contact?error=1'); }
});

app.post('/request-pro', async (req, res) => {
  try {
    const { name, email, phone, zip, service, details } = req.body;
    const client = getPostmark();
    await client.sendEmail({ From: SUPPORT, To: SUPPORT, ReplyTo: email, Subject: 'UpkeepQR — Request a Pro',
      HtmlBody: `<h3>New Pro Request</h3><p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p><strong>Phone:</strong> ${phone}</p><p><strong>ZIP:</strong> ${zip}</p><p><strong>Service:</strong> ${service}</p><pre>${details || ''}</pre>`, MessageStream: 'outbound' });
    await client.sendEmail({ From: SUPPORT, To: email, Subject: 'We received your pro request', HtmlBody: `<p>Hi ${name},</p><p>We received your request for ${service}. We'll connect you with a local professional shortly.</p>`, MessageStream: 'outbound' });
    res.redirect('/request-a-pro?sent=1');
  } catch (e) { console.error(e); res.redirect('/request-a-pro?error=1'); }
});

app.post('/fee-listing', async (req, res) => {
  try {
    const { name, email, address, type, sqft, notes } = req.body;
    const client = getPostmark();
    await client.sendEmail({ From: SUPPORT, To: SUPPORT, ReplyTo: email, Subject: 'UpkeepQR — New Property Listing',
      HtmlBody: `<h3>New Property Listing</h3><p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p><strong>Address:</strong> ${address}</p><p><strong>Type:</strong> ${type}</p><p><strong>Sqft:</strong> ${sqft || ''}</p><pre>${notes || ''}</pre>`, MessageStream: 'outbound' });
    await client.sendEmail({ From: SUPPORT, To: email, Subject: 'Thanks for submitting your property', HtmlBody: `<p>Hi ${name},</p><p>Thanks for sending your property details. Our team will review and follow up with next steps.</p>`, MessageStream: 'outbound' });
    res.redirect('/fee-listing?sent=1');
  } catch (e) { console.error(e); res.redirect('/fee-listing?error=1'); }
});

export const api = functions.https.onRequest(app);
